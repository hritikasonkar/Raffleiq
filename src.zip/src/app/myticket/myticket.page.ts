import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-myticket',
  templateUrl: './myticket.page.html',
  styleUrls: ['./myticket.page.scss'],
})
export class MyticketPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
