import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MenuController, NavParams } from '@ionic/angular';

@Component({
  selector: 'app-after-splash-screen',
  templateUrl: './after-splash-screen.page.html',
  styleUrls: ['./after-splash-screen.page.scss'],
})
export class AfterSplashScreenPage implements OnInit {

  constructor(private route: Router,public menuCtrl: MenuController) { }
  ionViewWillEnter() {
    this.menuCtrl.enable(false);
   }

  ngOnInit() {
  }
  loginpage() {
    this.route.navigate(['/login']);
  }
  player(){
    this.route.navigateByUrl('/login'); 
    localStorage.setItem("user_type", '1');

  }
  business(){
    this.route.navigateByUrl('/login'); 
    localStorage.setItem("user_type", '2');

  }
  
}
