import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-detailspage',
  templateUrl: './detailspage.page.html',
  styleUrls: ['./detailspage.page.scss'],
})
export class DetailspagePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
