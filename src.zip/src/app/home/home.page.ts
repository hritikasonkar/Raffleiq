import { Component, OnInit } from '@angular/core';
import {AuthServiceService} from '../auth-service.service'
@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})
export class HomePage implements OnInit {
  type: string;
  result:any;
  rafflists=[];
  privateList=[];
  prvresult:any;

  constructor(public authService:AuthServiceService) { }

  ngOnInit() {
    this.type = 'public';
    // this.private();
    this.callList(1);
    this.callList(2);
    // this.public();

  }
  segmentChanged(ev: any) {
    console.log('Segment changed', ev);
  }
  

  callList(type_id){
    this.authService.List(type_id).subscribe((response :any) =>{
      console.log(response);
      //this.prvresult=response;
      if(response.status==1){
        if(type_id===1){
          this.rafflists=response.data || [];
          

        }
        else{
          
         // this.privateList=response.data;
          this.privateList=response.data || [] ;
        }

      }
      else{

      }

    },
    error=>{
      console.log("internal server error")
    }
    )
  }

}
