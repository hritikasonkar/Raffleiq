import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-view-participant',
  templateUrl: './view-participant.page.html',
  styleUrls: ['./view-participant.page.scss'],
})
export class ViewParticipantPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
